<?php

$conn = mysqli_connect('localhost', 'root', '', 'icounsel') or die("Can't connect'");
